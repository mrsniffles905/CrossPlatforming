﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Entity : MonoBehaviour
{

    //movement
    public float speed = 10;
    public float jumpForce = 10;
    protected float horizontal = 0;
    public int jumpCount;

    //shoot
    public GameObject projectile;
    public Transform spawnPoint;
    public float projectileForce = 50;

    // groundcheck
    protected bool isGrounded;
    protected Rigidbody2D rb;

    //animator
    public Animator anim;
    public bool dead = false;
    

    //death
    public bool death = false;

    //Enemy
    public int enemyLayer;

    // Use this for initialization
    protected virtual void Start()
    {
        rb = GetComponent<Rigidbody2D>();

    }


    public virtual void Death()
    {
        
    }
    public float GetHorizontalSpeed()
    {
        return speed * horizontal;
    }

    public virtual void Move()
    {
        transform.position += speed * horizontal * Vector3.right * Time.deltaTime;
        if (horizontal > 0.5f)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (horizontal < -0.5f)
        {
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }

    }

    public virtual void Jump()
    {
       
        {
            isGrounded = false;
            rb.AddForce(jumpForce * Vector3.up, ForceMode2D.Impulse);
        }

    }

    public virtual void OnGroundHit()
    {

        isGrounded = true;
        
    }

    public virtual void OnEnemyHit(GameObject enemy)
    {

    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 8)
        {
            OnGroundHit();
        }
        if (collision.gameObject.layer == enemyLayer)
        {
            OnEnemyHit(collision.gameObject);
        }
    }

    public virtual void Shoot()
    {
        
        {
            GameObject spawnedProjectile = Instantiate(projectile, spawnPoint.position, Quaternion.identity);
            spawnedProjectile.GetComponent<Rigidbody2D>().AddForce(projectileForce * transform.right, ForceMode2D.Impulse);
        }

    }

}