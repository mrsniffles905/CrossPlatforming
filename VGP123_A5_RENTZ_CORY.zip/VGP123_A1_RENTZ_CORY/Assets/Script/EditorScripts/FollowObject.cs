﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowObject : MonoBehaviour {

    public Transform target;
    public Vector3 offset;
    public float lerpSpeed = 0.5f;

	// Use this for initialization
	void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {
        //Vector3 desiredPosition = target.position + offset;
        //transform.position = Vector3.Lerp(transform.position, desiredPosition, lerpSpeed * Time.deltaTime);


        float newY;

        Vector3 pos = transform.position;
        pos.x = target.position.x;
        pos.y = target.position.y;

        // transform.position = pos;   Orig

        //*************** Phil version
        newY = pos.y / 5;
        transform.position = new Vector3(pos.x, newY, -10);
    }
}
